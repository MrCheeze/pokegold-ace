This .doc may be freely changed and expanded.
However, the original Credits of the original author including all his thanks must be included.
Additionally, a change log and a link or other as to where the original is obtainable is necessary. 

- Tauwasser
